#include "linkedList.h"
void prt(ElemType e)
{
	printf("%d\t",e);
}
/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList *L)
{
	(*L)=(LinkedList)malloc(sizeof(LNode));
	(*L)->next=NULL;
	return SUCCESS;
}

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */
void DestroyList(LinkedList *L)
{
	LinkedList p,q;
	q=(*L)->next;
	while(q)
	{
		p=q->next;
		free(q);
		q=p;
	}
	(*L)->next=q;
}

/**
 *  @name        : Status InsertList(LNode *p, LNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : Status
 *  @notice      : None
 */
Status InsertList(LNode *p, LNode *q)
{

	q->next=p->next;
	p->next=q;
	return SUCCESS;
}

/**
 *  @name        : Status DeleteList(LNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : Status
 *  @notice      : None
 */
Status DeleteList(LNode *p, ElemType *e)
{
	if(p==NULL||p->next==NULL)
	return ERROR;
	LNode *q;
	q=p->next;
	*e=q->data;
	p->next=q->next;
	free(q);
	return SUCCESS;
}

/**
 *  @name        : void TraverseList(LinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : None
 *  @notice      : None
 */
void TraverseList(LinkedList L, void (*visit)(ElemType e))
{

	while(L!=NULL&&L->next!=NULL)
	{
		L=L->next;
		visit(L->data);
	}
}

/**
 *  @name        : Status SearchList(LinkedList L, ElemType e)
 *	@description : find the first node in the linked list according to e
 *	@param		 : L(the head node), e
 *	@return		 : Status
 *  @notice      : None
 */
Status SearchList(LinkedList L, ElemType e)
{
	if(L->next==NULL)
	{
		printf("�����ݲ�����\n");
		return ERROR;
	}

	LinkedList p=L->next;
	while(p->data!=e&&p!=NULL)
	{
		p=p->next;
		if(p==NULL)
		{

			printf("�����ݲ�����\n");
			return ERROR;
		}
	}
	printf("�����ݴ���\n");
	return SUCCESS;
}

/**
 *  @name        : Status ReverseList(LinkedList *L)
 *	@description : reverse the linked list
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status ReverseList(LinkedList *L)
{
	if(*L==NULL||L==NULL)
	return ERROR;
	LNode*p,*q,*tem;
	p = (*L)->next;
	(*L)->next = NULL;
	q = tem = NULL;
	while(p){
		q = p->next;
		p->next = tem;
		tem = p;
		p = q;
	}
	(*L)->next = tem;
	return SUCCESS;
}

/**
 *  @name        : Status IsLoopList(LinkedList L)
 *	@description : judge whether the linked list is looped
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status IsLoopList(LinkedList L)
{
	if(L==NULL||L->next==NULL)
	return ERROR;
	LinkedList fast,slow;
	fast=slow=L;
	fast=fast->next->next;
	slow=slow->next;
	while(1)
	{
		if(fast==NULL||slow==NULL)
		return ERROR;
		if(fast==slow)
		return SUCCESS;
		else
		{
			fast=fast->next->next;
			slow=slow->next;
		}
	}
}

/**
 *  @name        : LNode* ReverseEvenList(LinkedList *L)
 *	@description : reverse the nodes which value is an even number in the linked list, input: 1 -> 2 -> 3 -> 4  output: 2 -> 1 -> 4 -> 3
 *	@param		 : L(the head node)
 *	@return		 : LNode(the new head node)
 *  @notice      : choose to finish
 */
LNode* ReverseEvenList(LinkedList *L)
{
	if((*L)==NULL||L==NULL)
	 return *L;
	 LinkedList a,b,c;
	 c=*L;
	 b=c->next;
	 a=b->next;
	 while(a!=NULL)
	 {
	 	if((a->data%2)==0)
	 	{
	 		b->next=a->next;
	 		a->next=b;
	 		c=a;
	 		a=b; 
	 		b=c; 
		 }
		 a=a->next;
		 b=b->next;
		 return *L;
	 }
}

/**
 *  @name        : LNode* FindMidNode(LinkedList *L)
 *	@description : find the middle node in the linked list
 *	@param		 : L(the head node)
 *	@return		 : LNode
 *  @notice      : choose to finish
 */
LNode* FindMidNode(LinkedList *L)
{
	if(*L==NULL||L==NULL)
	return *L;
	LinkedList fast=*L,slow=*L;
	while(fast->next!=NULL&&fast->next->next)
	{
		fast=fast->next->next;
		slow=slow->next;
	 }
	return slow;
}

 /**************************************************************
*	End-Multi-Include-Prevent Section
**************************************************************/
