#include "duLinkedList.h"

/**
 *  @name        : Status InitList_DuL(DuLinkedList *L)
 *	@description : initialize an empty linked list with only the head node
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList_DuL(DuLinkedList *L)
{
	(*L)=(DuLNode*)malloc(sizeof(DuLNode));
	(*L)->next=NULL;
	(*L)->prior=NULL;
	return SUCCESS;
}

/**
 *  @name        : void DestroyList_DuL(DuLinkedList *L)
 *	@description : destroy a linked list
 *	@param		 : L(the head node)
 *	@return		 : status
 *  @notice      : None
 */
void DestroyList_DuL(DuLinkedList *L) 
{
	DuLinkedList p,q;
	q=(*L)->next;
	while(q)
	{
		p=q->next;
		free(q);
		q=p;
	}
	(*L)->next=q;
}

/**
 *  @name        : Status InsertBeforeList_DuL(DuLNode *p, LNode *q)
 *	@description : insert node q before node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertBeforeList_DuL(DuLNode *p, DuLNode *q) 
{
	q->prior=p->prior;
	q->next=p;
	return SUCCESS;
}

/**
 *  @name        : Status InsertAfterList_DuL(DuLNode *p, DuLNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : status
 *  @notice      : None
 */
Status InsertAfterList_DuL(DuLNode *p, DuLNode *q) 
{
	q->next=p->next;
	q->prior=p;
	p->next=q;
	return SUCCESS;
}
/**
 *  @name        : Status DeleteList_DuL(DuLNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : status
 *  @notice      : None
 */
Status DeleteList_DuL(DuLNode *p, ElemType *e) 
{
	if(p==NULL||p->next==NULL)
	{
		printf("�޴�����");
		return ERROR;
	}
	DuLNode *q,*nq=NULL;
	q=p->next;
	if(q->next==NULL)
	{
		*e=p->next->data;
		p->next=NULL;
		free(q);
		return SUCCESS;
	}
	nq=q->next;
	*e=q->data;
	p->next=nq;
        nq->prior=p;
	free(q);
	return SUCCESS;
}

/**
 *  @name        : void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : Status
 *  @notice      : None
 */
 
void TraverseList_DuL(DuLinkedList L, void (*visit)(ElemType e))
{
	while(L!=NULL&&L->next!=NULL)
	{
		L=L->next;
		visit(L->data);
	}
}
Status ReverseList(DuLinkedList *L)
{
	if(*L==NULL||L==NULL)
	return ERROR;
	DuLNode*p,*q,*tem;
	p = (*L)->next;
	(*L)->next = NULL;
	q = tem = NULL;
	while(p){
		q = p->next;
		p->prior=q;
		p->next = tem;
		tem = p;
		p = q;
	}
	(*L)->next = tem;

	return SUCCESS;
}





